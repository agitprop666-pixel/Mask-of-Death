#!/usr/bin/env python3
"""
Mask of Death - MAC Address Spoofing Tool
Death's Head Software
"""

from __future__ import annotations

import sys
import os
import platform
import subprocess
import re
import time
import random
import json
from pathlib import Path

from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QThread
from PyQt6.QtGui import QFont, QColor, QPainter, QPixmap, QPalette, QIcon
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QComboBox, QPushButton, QLineEdit, QTextEdit,
    QGroupBox, QMessageBox, QSplashScreen, QSizePolicy
)


# =============================================================================
# Global Definitions
# =============================================================================
APP_NAME    = "Mask of Death"
ORG_NAME    = "Death's Head Software"
VERSION     = "1.1.0"

# Registry path for network adapter class drivers
NIC_CLASS_KEY = r"SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002BE10318}"


# =============================================================================
# Splash Screen
# =============================================================================
def create_splash() -> QSplashScreen | None:
    """Creates the splash screen for Mask of Death."""
    try:
        splash_path = Path(__file__).parent / "splash.png"

        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(
                    800, 600,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation
                )
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))

        painter = QPainter(pixmap)
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
        text_rect = pixmap.rect()
        text_rect.setTop(40)
        text_rect.setBottom(100)
        painter.drawText(
            text_rect,
            Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
            APP_NAME
        )

        if not splash_path.exists():
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art):
                painter.drawText(250, y_start + (i * 25), line)

        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        footer_rect = pixmap.rect()
        footer_rect.setTop(pixmap.height() - 100)
        footer_rect.setBottom(pixmap.height() - 50)
        painter.drawText(
            footer_rect,
            Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
            ORG_NAME
        )
        painter.end()

        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception:
        return None


# =============================================================================
# Subprocess Helper — No Console Window on Windows
# =============================================================================
def run_proc(*args, **kwargs) -> subprocess.CompletedProcess:
    """Run a subprocess without spawning a visible console window on Windows."""
    if platform.system() == "Windows":
        if "startupinfo" not in kwargs:
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = subprocess.SW_HIDE
            kwargs["startupinfo"] = si
        kwargs.setdefault("creationflags", subprocess.CREATE_NO_WINDOW)
    return subprocess.run(*args, **kwargs)


# =============================================================================
# Privilege Checking
# =============================================================================
def is_admin() -> bool:
    """Return True if the process has administrator / root privileges."""
    try:
        if platform.system() == "Windows":
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        else:
            return os.geteuid() == 0
    except Exception:
        return False


def privilege_message() -> str:
    """Return a human-readable message explaining how to gain privileges."""
    if platform.system() == "Windows":
        return (
            "Administrator privileges are required to change MAC addresses.\n\n"
            "Please restart this application by:\n"
            "  1. Right-clicking on the executable\n"
            "  2. Selecting 'Run as administrator'\n\n"
            "Or run from an Administrator Command Prompt."
        )
    return (
        "Root privileges are required to change MAC addresses.\n\n"
        "Please restart using:\n"
        "  sudo ./mask-of-death\n\n"
        "Or use the desktop launcher, which will prompt for your password."
    )


# =============================================================================
# MAC Address Utilities
# =============================================================================
class MACUtils:
    """Static helpers for MAC address validation, generation, and formatting."""

    @staticmethod
    def validate(mac: str) -> bool:
        """Accept any of: AABBCCDDEEFF / AA:BB:CC:DD:EE:FF / AA-BB-CC-DD-EE-FF"""
        clean = re.sub(r"[:\-]", "", mac).upper()
        return bool(re.fullmatch(r"[0-9A-F]{12}", clean))

    @staticmethod
    def to_bare(mac: str) -> str:
        """Return MAC as 12 uppercase hex chars, no separators (registry format)."""
        return re.sub(r"[:\-]", "", mac).upper()

    @staticmethod
    def to_colon(mac: str) -> str:
        """Return MAC in AA:BB:CC:DD:EE:FF format."""
        bare = re.sub(r"[:\-]", "", mac).upper()
        return ":".join(bare[i:i+2] for i in range(0, 12, 2))

    @staticmethod
    def random_mac(locally_administered: bool = True) -> str:
        """Generate a random locally-administered unicast MAC address."""
        octets = [random.randint(0, 255) for _ in range(6)]
        if locally_administered:
            octets[0] = (octets[0] & 0xFE) | 0x02   # LA=1, MC=0
        return ":".join(f"{b:02X}" for b in octets)


# =============================================================================
# Windows — Registry Operations (winreg, no subprocess)
# =============================================================================
def _find_nic_subkey(adapter_guid: str) -> str | None:
    """
    Walk HKLM\\...\\{4D36E972...} and return the subkey name (e.g. '0001')
    whose NetCfgInstanceId value matches adapter_guid.

    Returns None if not found. Raises PermissionError if access is denied.
    """
    import winreg
    try:
        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE, NIC_CLASS_KEY, 0, winreg.KEY_READ
        ) as base:
            i = 0
            while True:
                try:
                    name = winreg.EnumKey(base, i)
                    i += 1
                    if not re.fullmatch(r"\d+", name):
                        continue          # skip non-numeric keys like "Properties"
                    with winreg.OpenKey(base, name, 0, winreg.KEY_READ) as sub:
                        try:
                            cfg_id = winreg.QueryValueEx(sub, "NetCfgInstanceId")[0]
                            if cfg_id.strip("{}").lower() == adapter_guid.strip("{}").lower():
                                return name
                        except FileNotFoundError:
                            pass
                except OSError:
                    break   # EnumKey exhausted
    except PermissionError:
        raise PermissionError(
            "Registry access denied — run Mask of Death as Administrator."
        )
    return None


def _reg_write_network_address(subkey_name: str, mac_bare: str) -> None:
    """Write NetworkAddress = mac_bare into the NIC class subkey."""
    import winreg
    path = f"{NIC_CLASS_KEY}\\{subkey_name}"
    with winreg.OpenKey(
        winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_SET_VALUE
    ) as key:
        winreg.SetValueEx(key, "NetworkAddress", 0, winreg.REG_SZ, mac_bare)


def _reg_delete_network_address(subkey_name: str) -> bool:
    """
    Delete the NetworkAddress override from the NIC class subkey.
    Returns True if deleted, False if it was not present.
    """
    import winreg
    path = f"{NIC_CLASS_KEY}\\{subkey_name}"
    with winreg.OpenKey(
        winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_SET_VALUE
    ) as key:
        try:
            winreg.DeleteValue(key, "NetworkAddress")
            return True
        except FileNotFoundError:
            return False


# =============================================================================
# Windows — Adapter Enumeration
# =============================================================================
def get_adapters_windows() -> dict[str, dict]:
    """
    Return {adapter_name: {"mac": str, "guid": str, "status": str}}
    using PowerShell Get-NetAdapter so we have Name AND GUID from the start.
    """
    ps = (
        "Get-NetAdapter | "
        "Where-Object { $_.MacAddress -ne $null -and $_.MacAddress -ne '' } | "
        "Select-Object Name,MacAddress,InterfaceGuid,Status | "
        "ConvertTo-Json -Compress"
    )
    try:
        result = run_proc(
            ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command", ps],
            capture_output=True, text=True, timeout=15
        )
        if result.returncode != 0 or not result.stdout.strip():
            return {}

        data = json.loads(result.stdout.strip())
        # PowerShell returns an object (not array) when there is only one adapter
        if isinstance(data, dict):
            data = [data]

        adapters = {}
        for item in data:
            name = item.get("Name", "").strip()
            mac  = item.get("MacAddress", "").strip().replace("-", ":").upper()
            guid = item.get("InterfaceGuid", "").strip().strip("{}")
            status = item.get("Status", "").strip()
            if name and mac:
                adapters[name] = {"mac": mac, "guid": guid, "status": status}
        return adapters
    except Exception:
        return {}


# =============================================================================
# Windows — MAC Spoof / Restore
# =============================================================================
def _restart_adapter_windows(adapter_name: str, cb) -> bool:
    """
    Disable then re-enable a Windows adapter by its exact Name
    using PowerShell Get-NetAdapter / Disable-NetAdapter / Enable-NetAdapter.
    Returns True on success.
    """
    safe_name = adapter_name.replace("'", "''")
    ps = f"""
$ErrorActionPreference = 'Stop'
try {{
    $a = Get-NetAdapter -Name '{safe_name}'
    Disable-NetAdapter -Name $a.Name -Confirm:$false
    Start-Sleep -Milliseconds 1500
    Enable-NetAdapter  -Name $a.Name -Confirm:$false
    Write-Output 'OK'
}} catch {{
    Write-Output "FAIL: $_"
    exit 1
}}
"""
    try:
        r = run_proc(
            ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command", ps],
            capture_output=True, text=True, timeout=20
        )
        out = r.stdout.strip()
        if r.returncode == 0 and out == "OK":
            return True
        cb(f"Adapter restart issue: {out or r.stderr.strip()}", "warning")
        return False
    except Exception as e:
        cb(f"Adapter restart exception: {e}", "warning")
        return False


def change_mac_windows(
    adapter_name: str,
    adapter_guid: str,
    new_mac: str,
    cb  # cb(message, level) — posts status to the UI log
) -> tuple[bool, str]:
    """
    Spoof the MAC address of a Windows adapter.

    adapter_name : exact Name from Get-NetAdapter (used for Disable/Enable)
    adapter_guid : InterfaceGuid from Get-NetAdapter (used for registry lookup)
    new_mac      : any standard MAC format
    cb           : callable(message: str, level: str) for live status updates

    Returns (success, summary_message).
    """
    if not MACUtils.validate(new_mac):
        return False, f"Invalid MAC address format: {new_mac}"

    mac_bare  = MACUtils.to_bare(new_mac)
    mac_colon = MACUtils.to_colon(new_mac)

    # ── 1. Locate registry subkey ──────────────────────────────────────────────
    cb("Locating registry subkey for adapter...", "info")
    try:
        subkey = _find_nic_subkey(adapter_guid)
    except PermissionError as e:
        return False, str(e)

    if subkey is None:
        return False, (
            f"Could not find a registry entry for adapter GUID {{{adapter_guid}}}.\n\n"
            "The adapter may not support MAC spoofing via the Windows registry.\n"
            "Check Device Manager → adapter Properties → Advanced tab for a\n"
            "'Network Address' or 'Locally Administered Address' property.\n"
            "If it exists but is blank or disabled, enable it there first."
        )
    cb(f"Found registry subkey: {subkey}", "info")

    # ── 2. Disable adapter ─────────────────────────────────────────────────────
    cb(f"Disabling adapter '{adapter_name}'...", "info")
    safe_name = adapter_name.replace("'", "''")
    r = run_proc(
        ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command",
         f"Disable-NetAdapter -Name '{safe_name}' -Confirm:$false"],
        capture_output=True, text=True, timeout=10
    )
    if r.returncode != 0:
        return False, (
            f"Failed to disable adapter '{adapter_name}'.\n\n"
            f"PowerShell error: {r.stderr.strip() or r.stdout.strip()}\n\n"
            "Ensure you are running as Administrator."
        )
    time.sleep(1.5)

    # ── 3. Write registry ──────────────────────────────────────────────────────
    cb("Writing NetworkAddress to registry...", "info")
    try:
        _reg_write_network_address(subkey, mac_bare)
    except PermissionError as e:
        # Re-enable before bailing so adapter isn't left disabled
        run_proc(
            ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command",
             f"Enable-NetAdapter -Name '{safe_name}' -Confirm:$false"],
            capture_output=True, timeout=10
        )
        return False, str(e)
    except Exception as e:
        run_proc(
            ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command",
             f"Enable-NetAdapter -Name '{safe_name}' -Confirm:$false"],
            capture_output=True, timeout=10
        )
        return False, f"Registry write failed: {e}"
    cb("Registry updated successfully.", "info")

    # ── 4. Re-enable adapter ───────────────────────────────────────────────────
    cb(f"Re-enabling adapter '{adapter_name}'...", "info")
    r = run_proc(
        ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command",
         f"Enable-NetAdapter -Name '{safe_name}' -Confirm:$false"],
        capture_output=True, text=True, timeout=10
    )
    if r.returncode != 0:
        return False, (
            f"Registry was updated to {mac_colon}, but the adapter could not "
            f"be re-enabled automatically.\n\n"
            "Please manually disable and re-enable the adapter in Network Connections\n"
            "(ncpa.cpl), or reboot, for the new MAC to take effect."
        )
    time.sleep(2)

    # ── 5. Verify ──────────────────────────────────────────────────────────────
    cb("Verifying MAC address change...", "info")
    actual = _read_mac_windows(adapter_name)
    if actual and MACUtils.to_bare(actual) == mac_bare:
        return True, f"MAC address successfully changed to {mac_colon}"
    elif actual:
        return False, (
            f"Registry was updated and adapter restarted, but the MAC did not change.\n\n"
            f"Current MAC : {actual}\n"
            f"Expected    : {mac_colon}\n\n"
            "Some drivers (particularly Intel wireless) ignore the NetworkAddress\n"
            "registry value unless 'Locally Administered Address' is also enabled\n"
            "in Device Manager → adapter → Properties → Advanced tab."
        )
    else:
        # Verification fell through — the change likely worked but we couldn't confirm
        return True, (
            f"MAC address set to {mac_colon}.\n\n"
            "Note: Could not verify the change via Get-NetAdapter — the adapter\n"
            "may still be initialising. Refresh the interface list in a few seconds."
        )


def restore_mac_windows(
    adapter_name: str,
    adapter_guid: str,
    cb
) -> tuple[bool, str]:
    """
    Remove the NetworkAddress registry override to restore the hardware MAC.
    """
    # ── 1. Locate registry subkey ──────────────────────────────────────────────
    cb("Locating registry subkey for adapter...", "info")
    try:
        subkey = _find_nic_subkey(adapter_guid)
    except PermissionError as e:
        return False, str(e)

    if subkey is None:
        return False, (
            f"Could not find a registry entry for adapter GUID {{{adapter_guid}}}.\n\n"
            "Refresh the interface list and try again."
        )

    # ── 2. Disable adapter ─────────────────────────────────────────────────────
    cb(f"Disabling adapter '{adapter_name}'...", "info")
    safe_name = adapter_name.replace("'", "''")
    run_proc(
        ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command",
         f"Disable-NetAdapter -Name '{safe_name}' -Confirm:$false"],
        capture_output=True, timeout=10
    )
    time.sleep(1.5)

    # ── 3. Delete NetworkAddress ───────────────────────────────────────────────
    cb("Removing NetworkAddress override from registry...", "info")
    try:
        was_set = _reg_delete_network_address(subkey)
    except PermissionError as e:
        run_proc(
            ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command",
             f"Enable-NetAdapter -Name '{safe_name}' -Confirm:$false"],
            capture_output=True, timeout=10
        )
        return False, str(e)
    except Exception as e:
        run_proc(
            ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command",
             f"Enable-NetAdapter -Name '{safe_name}' -Confirm:$false"],
            capture_output=True, timeout=10
        )
        return False, f"Registry delete failed: {e}"

    if not was_set:
        run_proc(
            ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command",
             f"Enable-NetAdapter -Name '{safe_name}' -Confirm:$false"],
            capture_output=True, timeout=10
        )
        return True, f"'{adapter_name}' is already using its hardware MAC — no override was set."

    # ── 4. Re-enable adapter ───────────────────────────────────────────────────
    cb(f"Re-enabling adapter '{adapter_name}'...", "info")
    run_proc(
        ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command",
         f"Enable-NetAdapter -Name '{safe_name}' -Confirm:$false"],
        capture_output=True, timeout=10
    )
    time.sleep(2)

    return True, f"Hardware MAC address restored for '{adapter_name}'."


def _read_mac_windows(adapter_name: str) -> str | None:
    """Return the current MAC of a Windows adapter via Get-NetAdapter, or None."""
    safe_name = adapter_name.replace("'", "''")
    ps = f"(Get-NetAdapter -Name '{safe_name}').MacAddress"
    try:
        r = run_proc(
            ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command", ps],
            capture_output=True, text=True, timeout=10
        )
        raw = r.stdout.strip()
        if raw:
            return raw.replace("-", ":").upper()
    except Exception:
        pass
    return None


# =============================================================================
# Linux — Adapter Enumeration and MAC Spoof
# =============================================================================
def get_adapters_linux() -> dict[str, dict]:
    """Return {iface: {"mac": str}} for all non-loopback physical interfaces."""
    try:
        result = run_proc(["ip", "-o", "link", "show"],
                          capture_output=True, text=True, check=True)
        adapters = {}
        for line in result.stdout.splitlines():
            m = re.match(r"\d+:\s+(\S+):.*link/ether\s+([\da-f:]+)", line)
            if m:
                name = m.group(1).rstrip("@")
                if name != "lo":
                    adapters[name] = {"mac": m.group(2).upper(), "guid": None}
        return adapters
    except Exception:
        return {}


def change_mac_linux(
    interface: str,
    new_mac: str,
    cb
) -> tuple[bool, str]:
    if not MACUtils.validate(new_mac):
        return False, f"Invalid MAC address format: {new_mac}"

    mac_colon = MACUtils.to_colon(new_mac)

    try:
        cb(f"Bringing '{interface}' down...", "info")
        run_proc(["ip", "link", "set", interface, "down"],
                 check=True, capture_output=True)

        cb("Setting new MAC address...", "info")
        run_proc(["ip", "link", "set", interface, "address", mac_colon],
                 check=True, capture_output=True)

        cb(f"Bringing '{interface}' back up...", "info")
        run_proc(["ip", "link", "set", interface, "up"],
                 check=True, capture_output=True)

        return True, f"MAC address changed to {mac_colon}"
    except subprocess.CalledProcessError as e:
        err = e.stderr.decode() if isinstance(e.stderr, bytes) else str(e.stderr or e)
        return False, f"Error changing MAC address: {err}"
    except Exception as e:
        return False, f"Unexpected error: {e}"


# =============================================================================
# Worker Thread
# =============================================================================
class MACWorker(QThread):
    """Runs MAC operations off the UI thread."""

    finished = pyqtSignal(bool, str)
    status   = pyqtSignal(str, str)   # message, level

    def __init__(self, operation: str, adapter_name: str,
                 adapter_guid: str | None = None, new_mac: str | None = None):
        super().__init__()
        self.operation    = operation
        self.adapter_name = adapter_name
        self.adapter_guid = adapter_guid or ""
        self.new_mac      = new_mac

    def _cb(self, message: str, level: str = "info"):
        self.status.emit(message, level)

    def run(self):
        system = platform.system()

        if self.operation == "change":
            if system == "Windows":
                ok, msg = change_mac_windows(
                    self.adapter_name, self.adapter_guid, self.new_mac, self._cb
                )
            elif system == "Linux":
                ok, msg = change_mac_linux(
                    self.adapter_name, self.new_mac, self._cb
                )
            else:
                ok, msg = False, f"Unsupported operating system: {system}"

        elif self.operation == "restore":
            if system == "Windows":
                ok, msg = restore_mac_windows(
                    self.adapter_name, self.adapter_guid, self._cb
                )
            else:
                ok, msg = False, f"Restore is not applicable on {system}."

        else:
            ok, msg = False, f"Unknown operation: {self.operation}"

        self.finished.emit(ok, msg)


# =============================================================================
# Main Application Window
# =============================================================================
MSGBOX_STYLE = """
    QMessageBox {
        background-color: #2A2A2A;
    }
    QMessageBox QLabel {
        color: #F0F0F0;
        font-size: 10pt;
    }
    QMessageBox QPushButton {
        background-color: #505050;
        color: #FFFFFF;
        border: 1px solid #606060;
        padding: 6px 20px;
        min-width: 80px;
        font-weight: bold;
    }
    QMessageBox QPushButton:hover {
        background-color: #606060;
    }
"""


class MaskOfDeathApp(QMainWindow):
    """Main application window."""

    def __init__(self):
        super().__init__()
        self.current_adapters: dict[str, dict] = {}   # name → {mac, guid}
        self.worker: MACWorker | None = None
        self.has_privileges = is_admin()

        self._load_icon()
        self._init_ui()
        self._apply_dark_theme()
        self.refresh_interfaces()

    # ── Icon ───────────────────────────────────────────────────────────────────

    def _load_icon(self):
        """Set the window icon — mirrors the approach that works in PyInstaller builds."""
        try:
            icon_paths = [
                Path(__file__).parent / "icon.ico",
                Path(sys.executable).parent / "icon.ico",
                Path("icon.ico"),
                Path(sys._MEIPASS) / "icon.ico" if hasattr(sys, "_MEIPASS") else None,
            ]
            for icon_path in icon_paths:
                if icon_path and icon_path.exists():
                    icon = QIcon(str(icon_path))
                    if not icon.isNull():
                        self.setWindowIcon(icon)
                        QApplication.instance().setWindowIcon(icon)
                        return
        except Exception:
            pass



    # ── UI construction ────────────────────────────────────────────────────────

    def _init_ui(self):
        self.setWindowTitle(f"{APP_NAME} — {ORG_NAME}")
        self.setGeometry(100, 100, 900, 700)
        self.setMinimumSize(700, 520)

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setSpacing(14)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Title
        title = QLabel(APP_NAME)
        title.setFont(QFont("Courier", 24, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(title)

        subtitle = QLabel("Network Interface MAC Address Spoofing Tool")
        subtitle.setFont(QFont("Arial", 10))
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(subtitle)

        # Privilege warning
        if not self.has_privileges:
            banner = QWidget()
            banner.setAutoFillBackground(True)
            pal = banner.palette()
            pal.setColor(QPalette.ColorRole.Window, QColor(139, 0, 0))
            banner.setPalette(pal)
            bl = QVBoxLayout(banner)
            bl.setContentsMargins(10, 10, 10, 10)
            warn_title = QLabel("⚠  WARNING: Running without elevated privileges")
            warn_title.setFont(QFont("Arial", 11, QFont.Weight.Bold))
            warn_title.setStyleSheet("color: white;")
            warn_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
            bl.addWidget(warn_title)
            warn_detail = QLabel(privilege_message())
            warn_detail.setFont(QFont("Arial", 9))
            warn_detail.setStyleSheet("color: white;")
            warn_detail.setWordWrap(True)
            bl.addWidget(warn_detail)
            main_layout.addWidget(banner)

        # ── Interface group ────────────────────────────────────────────────────
        iface_group = QGroupBox("Network Interface")
        iface_group.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        iface_layout = QVBoxLayout()

        row1 = QHBoxLayout()
        iface_lbl = QLabel("Interface:")
        iface_lbl.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        row1.addWidget(iface_lbl)

        self.interface_combo = QComboBox()
        self.interface_combo.setFont(QFont("Courier", 10))
        self.interface_combo.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed
        )
        self.interface_combo.currentIndexChanged.connect(self._on_interface_changed)
        row1.addWidget(self.interface_combo)

        self.refresh_btn = QPushButton("🔄 Refresh")
        self.refresh_btn.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        self.refresh_btn.setMinimumHeight(32)
        self.refresh_btn.clicked.connect(self.refresh_interfaces)
        row1.addWidget(self.refresh_btn)
        iface_layout.addLayout(row1)

        self.current_mac_label = QLabel("Current MAC: —")
        self.current_mac_label.setFont(QFont("Courier", 11))
        iface_layout.addWidget(self.current_mac_label)

        iface_group.setLayout(iface_layout)
        main_layout.addWidget(iface_group)

        # ── MAC configuration group ────────────────────────────────────────────
        mac_group = QGroupBox("MAC Address Configuration")
        mac_group.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        mac_layout = QVBoxLayout()

        mac_input_row = QHBoxLayout()
        mac_lbl = QLabel("New MAC:")
        mac_lbl.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        mac_input_row.addWidget(mac_lbl)
        self.mac_input = QLineEdit()
        self.mac_input.setFont(QFont("Courier", 10))
        self.mac_input.setPlaceholderText("AA:BB:CC:DD:EE:FF")
        mac_input_row.addWidget(self.mac_input)
        mac_layout.addLayout(mac_input_row)

        btn_row = QHBoxLayout()
        self.random_btn = QPushButton("🎲 Generate Random")
        self.random_btn.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        self.random_btn.setMinimumHeight(32)
        self.random_btn.clicked.connect(self._generate_random)
        btn_row.addWidget(self.random_btn)

        self.apply_btn = QPushButton("✓ Apply MAC Address")
        self.apply_btn.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        self.apply_btn.setMinimumHeight(32)
        self.apply_btn.clicked.connect(self._apply_mac)
        btn_row.addWidget(self.apply_btn)

        self.restore_btn = QPushButton("↺ Restore Original")
        self.restore_btn.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        self.restore_btn.setMinimumHeight(32)
        self.restore_btn.clicked.connect(self._restore_mac)
        btn_row.addWidget(self.restore_btn)

        mac_layout.addLayout(btn_row)

        system = platform.system()
        if system == "Windows":
            persist_text = "ℹ  Windows: MAC changes persist across reboots (stored in registry)."
        elif system == "Linux":
            persist_text = "ℹ  Linux: MAC changes are temporary and revert after reboot."
        else:
            persist_text = "ℹ  MAC address persistence depends on your operating system."

        persist_lbl = QLabel(persist_text)
        persist_lbl.setFont(QFont("Arial", 8))
        persist_lbl.setWordWrap(True)
        persist_lbl.setStyleSheet("color: #B0B0B0; font-style: italic;")
        mac_layout.addWidget(persist_lbl)

        mac_group.setLayout(mac_layout)
        main_layout.addWidget(mac_group)

        # ── Activity log ───────────────────────────────────────────────────────
        log_group = QGroupBox("Activity Log")
        log_group.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        log_layout = QVBoxLayout()

        self.log_text = QTextEdit()
        self.log_text.setFont(QFont("Courier", 9))
        self.log_text.setReadOnly(True)
        self.log_text.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding
        )
        log_layout.addWidget(self.log_text)

        clear_btn = QPushButton("Clear Log")
        clear_btn.setFont(QFont("Arial", 9, QFont.Weight.Bold))
        clear_btn.setMinimumHeight(28)
        clear_btn.clicked.connect(self.log_text.clear)
        log_layout.addWidget(clear_btn)

        log_group.setLayout(log_layout)
        main_layout.addWidget(log_group)

        # Footer
        footer = QLabel(f"{ORG_NAME}  •  v{VERSION}")
        footer.setFont(QFont("Arial", 8))
        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(footer)

        self.log(f"Application started  |  OS: {platform.system()}  |  v{VERSION}")
        if platform.system() not in ("Windows", "Linux"):
            self.log("WARNING: This OS may not be fully supported.", "warning")

    # ── Dark theme ─────────────────────────────────────────────────────────────

    def _apply_dark_theme(self):
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window,          QColor(30, 30, 30))
        palette.setColor(QPalette.ColorRole.WindowText,      QColor(240, 240, 240))
        palette.setColor(QPalette.ColorRole.Base,            QColor(45, 45, 45))
        palette.setColor(QPalette.ColorRole.AlternateBase,   QColor(50, 50, 50))
        palette.setColor(QPalette.ColorRole.Text,            QColor(240, 240, 240))
        palette.setColor(QPalette.ColorRole.Button,          QColor(60, 60, 60))
        palette.setColor(QPalette.ColorRole.ButtonText,      QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Link,            QColor(100, 150, 255))
        palette.setColor(QPalette.ColorRole.Highlight,       QColor(80, 80, 120))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.ToolTipBase,     QColor(50, 50, 50))
        palette.setColor(QPalette.ColorRole.ToolTipText,     QColor(255, 255, 255))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.WindowText, QColor(120, 120, 120))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor(120, 120, 120))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text,       QColor(120, 120, 120))
        self.setPalette(palette)
        QApplication.instance().setPalette(palette)

        self.setStyleSheet("""
            QPushButton {
                background-color: #505050;
                color: #FFFFFF;
                border: 1px solid #606060;
                padding: 6px 12px;
                border-radius: 3px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #606060;
                border: 1px solid #707070;
            }
            QPushButton:pressed    { background-color: #404040; }
            QPushButton:disabled   { background-color: #3A3A3A; color: #808080; }

            QComboBox {
                background-color: #3A3A3A;
                color: #F0F0F0;
                border: 1px solid #505050;
                padding: 4px;
                border-radius: 3px;
            }
            QComboBox:hover { border: 1px solid #606060; }
            QComboBox::drop-down { border: none; }
            QComboBox QAbstractItemView {
                background-color: #3A3A3A;
                color: #F0F0F0;
                selection-background-color: #505060;
                selection-color: #FFFFFF;
            }

            QLineEdit {
                background-color: #3A3A3A;
                color: #F0F0F0;
                border: 1px solid #505050;
                padding: 4px;
                border-radius: 3px;
            }
            QLineEdit:focus { border: 1px solid #606060; }

            QTextEdit {
                background-color: #1A1A1A;
                color: #F0F0F0;
                border: 1px solid #505050;
                selection-background-color: #505060;
                selection-color: #FFFFFF;
            }

            QGroupBox {
                background-color: #282828;
                border: 1px solid #505050;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                color: #F0F0F0;
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }

            QLabel { color: #F0F0F0; }

            QMessageBox { background-color: #2A2A2A; }
            QMessageBox QLabel { color: #F0F0F0; }
            QMessageBox QPushButton { min-width: 80px; }

            QMenu {
                background-color: #E0E0E0;
                color: #000000;
                border: 1px solid #808080;
            }
            QMenu::item { background-color: transparent; color: #000000; padding: 5px 20px; }
            QMenu::item:selected { background-color: #0078D7; color: #FFFFFF; }
            QMenu::item:disabled { color: #808080; }
        """)

    # ── Helpers ────────────────────────────────────────────────────────────────

    def log(self, message: str, level: str = "info"):
        timestamp = time.strftime("%H:%M:%S")
        prefix = {"info": "ℹ", "success": "✓", "error": "✗", "warning": "⚠"}.get(level, "•")
        color  = {"info": "#F5F5F5", "success": "#80FF80", "error": "#FF8080", "warning": "#FFCC80"}.get(level, "#F5F5F5")
        self.log_text.append(
            f'<span style="color:{color};">[{timestamp}] {prefix} {message}</span>'
        )

    def _msgbox(self, title: str, message: str,
                icon: QMessageBox.Icon = QMessageBox.Icon.Information) -> int:
        box = QMessageBox(self)
        box.setWindowTitle(title)
        box.setText(message)
        box.setIcon(icon)
        box.setStyleSheet(MSGBOX_STYLE)
        return box.exec()

    def _confirm(self, title: str, message: str) -> bool:
        box = QMessageBox(self)
        box.setWindowTitle(title)
        box.setText(message)
        box.setIcon(QMessageBox.Icon.Question)
        box.setStandardButtons(
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        box.setStyleSheet(MSGBOX_STYLE)
        return box.exec() == QMessageBox.StandardButton.Yes

    def _selected_adapter(self) -> tuple[str, dict] | tuple[None, None]:
        """Return (name, adapter_dict) for the currently selected interface."""
        name = self.interface_combo.currentData()
        if name and name in self.current_adapters:
            return name, self.current_adapters[name]
        return None, None

    def _set_buttons_busy(self, busy: bool, apply_text: str = "✓ Apply MAC Address",
                          restore_text: str = "↺ Restore Original"):
        self.apply_btn.setEnabled(not busy)
        self.restore_btn.setEnabled(not busy)
        self.refresh_btn.setEnabled(not busy)
        self.apply_btn.setText("Applying..." if busy else apply_text)
        self.restore_btn.setText("Restoring..." if (busy and restore_text == "Restoring...") else restore_text)

    # ── Interface management ───────────────────────────────────────────────────

    def refresh_interfaces(self):
        self.log("Refreshing network interfaces...")
        self.interface_combo.clear()
        self.current_adapters = {}

        system = platform.system()
        if system == "Windows":
            self.current_adapters = get_adapters_windows()
        elif system == "Linux":
            self.current_adapters = get_adapters_linux()
        else:
            self.log(f"Unsupported operating system: {system}", "error")
            return

        if self.current_adapters:
            for name, info in self.current_adapters.items():
                display = f"{name}  ({info['mac']})"
                self.interface_combo.addItem(display, name)
            self.log(f"Found {len(self.current_adapters)} interface(s).", "success")
        else:
            self.log("No network interfaces found.", "warning")

        self._on_interface_changed()

    def _on_interface_changed(self):
        name, info = self._selected_adapter()
        if info:
            self.current_mac_label.setText(f"Current MAC:  {info['mac']}")
        else:
            self.current_mac_label.setText("Current MAC:  —")

    # ── Actions ────────────────────────────────────────────────────────────────

    def _generate_random(self):
        mac = MACUtils.random_mac()
        self.mac_input.setText(mac)
        self.log(f"Generated random MAC: {mac}")

    def _apply_mac(self):
        name, info = self._selected_adapter()
        if not name:
            self._msgbox("No Interface", "Please select a network interface.",
                         QMessageBox.Icon.Warning)
            return

        new_mac = self.mac_input.text().strip()
        if not new_mac:
            self._msgbox("No MAC Address", "Please enter a MAC address.",
                         QMessageBox.Icon.Warning)
            return

        if not MACUtils.validate(new_mac):
            self._msgbox("Invalid MAC",
                         "Invalid MAC address format.\nUse format: AA:BB:CC:DD:EE:FF",
                         QMessageBox.Icon.Warning)
            return

        new_mac_display = MACUtils.to_colon(new_mac)
        if not self._confirm(
            "Confirm MAC Change",
            f"Change MAC address of '{name}' to '{new_mac_display}'?"
        ):
            return

        self.log(f"Changing MAC of '{name}' to {new_mac_display}...")
        self._set_buttons_busy(True)
        self.apply_btn.setText("Applying...")

        self.worker = MACWorker(
            "change", name, info.get("guid", ""), new_mac_display
        )
        self.worker.status.connect(self.log)
        self.worker.finished.connect(self._on_change_done)
        self.worker.start()

    def _on_change_done(self, success: bool, message: str):
        self._set_buttons_busy(False)
        if success:
            self.log(message, "success")
            self._msgbox("Success", message, QMessageBox.Icon.Information)
            QTimer.singleShot(1500, self.refresh_interfaces)
        else:
            self.log(message, "error")
            self._msgbox("Error", message, QMessageBox.Icon.Critical)

    def _restore_mac(self):
        name, info = self._selected_adapter()
        if not name:
            self._msgbox("No Interface", "Please select a network interface.",
                         QMessageBox.Icon.Warning)
            return

        system = platform.system()
        if system == "Linux":
            self._msgbox(
                "Restore Original MAC — Linux",
                f"On Linux, MAC changes are temporary.\n\n"
                f"To restore '{name}', simply reboot, or restart NetworkManager:\n"
                f"  sudo systemctl restart NetworkManager",
                QMessageBox.Icon.Information
            )
            return

        if system != "Windows":
            self._msgbox("Unsupported OS",
                         f"MAC restoration is not supported on {system}.",
                         QMessageBox.Icon.Warning)
            return

        if not self._confirm(
            "Restore Original MAC",
            f"Remove the custom MAC override for '{name}'?\n\n"
            "The adapter will be restarted and the hardware MAC will be restored."
        ):
            return

        self.log(f"Restoring original MAC for '{name}'...")
        self._set_buttons_busy(True)
        self.restore_btn.setText("Restoring...")

        self.worker = MACWorker("restore", name, info.get("guid", ""))
        self.worker.status.connect(self.log)
        self.worker.finished.connect(self._on_restore_done)
        self.worker.start()

    def _on_restore_done(self, success: bool, message: str):
        self._set_buttons_busy(False)
        self.restore_btn.setText("↺ Restore Original")
        if success:
            self.log(message, "success")
            self._msgbox("Success", message, QMessageBox.Icon.Information)
            QTimer.singleShot(1500, self.refresh_interfaces)
        else:
            self.log(message, "error")
            self._msgbox("Error", message, QMessageBox.Icon.Critical)


# =============================================================================
# Splash Manager
# =============================================================================
class SplashManager:
    """Sequences the splash screen messages then launches the main window."""

    MESSAGES = [
        "Initializing...",
        "Loading network modules...",
        "Scanning interfaces...",
        "Preparing disguise...",
        "Almost ready...",
    ]
    INTERVAL_MS = 1100

    def __init__(self, app: QApplication):
        self.app         = app
        self.splash      = create_splash()
        self._msg_index  = 0
        self.main_window = None

    def show(self):
        if self.splash:
            self.splash.show()
            self.app.processEvents()
        self._next_message()

    def _next_message(self):
        if self._msg_index < len(self.MESSAGES):
            if self.splash:
                self.splash.showMessage(
                    "\n\n\n\n\n\n\n" + self.MESSAGES[self._msg_index],
                    Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                    QColor(255, 255, 255)
                )
            self._msg_index += 1
            QTimer.singleShot(self.INTERVAL_MS, self._next_message)
        else:
            QTimer.singleShot(100, self._show_main)

    def _show_main(self):
        self.main_window = MaskOfDeathApp()
        self.main_window.show()
        if self.splash:
            self.splash.finish(self.main_window)


# =============================================================================
# Entry Point
# =============================================================================
def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)

    # Set icon on QApplication before any windows are created so the taskbar
    # picks it up immediately.  Must call both the instance AND class method —
    # the class method is what propagates to the taskbar in PyInstaller builds.
    try:
        if getattr(sys, "frozen", False):
            base_path = Path(sys._MEIPASS)
        else:
            base_path = Path(__file__).parent

        icon_candidates = [
            base_path / "icon.ico",
            base_path / "icon.png",
            Path(__file__).parent / "icon.ico" if not getattr(sys, "frozen", False) else None,
        ]
        for candidate in icon_candidates:
            if candidate and candidate.exists():
                app_icon = QIcon(str(candidate))
                if not app_icon.isNull():
                    app.setWindowIcon(app_icon)
                    QApplication.setWindowIcon(app_icon)  # class method — critical for taskbar
                    break
    except Exception:
        pass

    sm = SplashManager(app)
    sm.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
